from flask import Flask, render_template, request, redirect, url_for, flash, abort
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime, date
from pathlib import Path
import qrcode
from urllib.parse import quote

BASE_DIR = Path(__file__).resolve().parent

app = Flask(__name__)
app.config["SECRET_KEY"] = "smart-traffic-demo-secret"
app.config["SQLALCHEMY_DATABASE_URI"] = f"sqlite:///{BASE_DIR / 'traffic.db'}"
app.config["SQLALCHEMY_TRACK_MODIFICATIONS"] = False

db = SQLAlchemy(app)

QR_DIR = BASE_DIR / "static" / "qr_codes"
QR_DIR.mkdir(parents=True, exist_ok=True)


class Violation(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    vehicle_number = db.Column(db.String(30), nullable=False, index=True)
    violation_type = db.Column(db.String(100), nullable=False)
    location = db.Column(db.String(150), nullable=False)
    violation_date = db.Column(db.Date, nullable=False, default=date.today)
    fine_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="Unpaid")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f"<Violation {self.id} {self.vehicle_number}>"


with app.app_context():
    db.create_all()


@app.route("/")
def index():
    total = Violation.query.count()
    unpaid = Violation.query.filter_by(status="Unpaid").count()
    paid = Violation.query.filter_by(status="Paid").count()
    recent = Violation.query.order_by(Violation.id.desc()).limit(5).all()
    return render_template("index.html", total=total, unpaid=unpaid, paid=paid, recent=recent)


@app.route("/add", methods=["GET", "POST"])
def add_violation():
    if request.method == "POST":
        vehicle_number = request.form.get("vehicle_number", "").strip().upper()
        violation_type = request.form.get("violation_type", "").strip()
        location = request.form.get("location", "").strip()
        date_text = request.form.get("violation_date", "").strip()
        fine_text = request.form.get("fine_amount", "").strip()

        if not all([vehicle_number, violation_type, location, date_text, fine_text]):
            flash("Please fill in all fields.", "error")
            return render_template("add_violation.html")

        try:
            violation_date = datetime.strptime(date_text, "%Y-%m-%d").date()
            fine_amount = float(fine_text)
            if fine_amount < 0:
                raise ValueError
        except ValueError:
            flash("Please enter a valid date and fine amount.", "error")
            return render_template("add_violation.html")

        violation = Violation(
            vehicle_number=vehicle_number,
            violation_type=violation_type,
            location=location,
            violation_date=violation_date,
            fine_amount=fine_amount,
            status="Unpaid",
        )
        db.session.add(violation)
        db.session.commit()

        generate_qr(violation)
        flash("Violation added successfully and QR code generated.", "success")
        return redirect(url_for("violation_detail", violation_id=violation.id))

    return render_template("add_violation.html", today=date.today().isoformat())


def generate_qr(violation):
    # QR points to the public status page for this exact violation.
    status_url = url_for("public_status", violation_id=violation.id, _external=True)
    qr = qrcode.make(status_url)
    qr.save(QR_DIR / f"violation_{violation.id}.png")


@app.route("/history")
def history():
    vehicle = request.args.get("vehicle", "").strip().upper()
    status = request.args.get("status", "").strip()
    violation_type = request.args.get("violation_type", "").strip()

    query = Violation.query

    if vehicle:
        query = query.filter(Violation.vehicle_number.contains(vehicle))
    if status in {"Paid", "Unpaid"}:
        query = query.filter_by(status=status)
    if violation_type:
        query = query.filter_by(violation_type=violation_type)

    violations = query.order_by(Violation.id.desc()).all()
    types = [row[0] for row in db.session.query(Violation.violation_type).distinct().order_by(Violation.violation_type).all()]

    return render_template(
        "history.html",
        violations=violations,
        types=types,
        vehicle=vehicle,
        status=status,
        selected_type=violation_type,
    )


@app.route("/violation/<int:violation_id>")
def violation_detail(violation_id):
    violation = db.get_or_404(Violation, violation_id)
    qr_file = f"qr_codes/violation_{violation.id}.png"
    return render_template("violation_detail.html", violation=violation, qr_file=qr_file)


@app.post("/violation/<int:violation_id>/mark-paid")
def mark_paid(violation_id):
    violation = db.get_or_404(Violation, violation_id)
    violation.status = "Paid"
    db.session.commit()
    generate_qr(violation)
    flash("Payment status updated to Paid.", "success")
    return redirect(url_for("violation_detail", violation_id=violation.id))


@app.post("/violation/<int:violation_id>/delete")
def delete_violation(violation_id):
    violation = db.get_or_404(Violation, violation_id)
    qr_path = QR_DIR / f"violation_{violation.id}.png"
    if qr_path.exists():
        qr_path.unlink()

    db.session.delete(violation)
    db.session.commit()
    flash("Violation deleted successfully.", "success")
    return redirect(url_for("history"))


@app.route("/status/<int:violation_id>")
def public_status(violation_id):
    # This is the page opened after scanning the QR code.
    violation = db.get_or_404(Violation, violation_id)
    return render_template("public_status.html", violation=violation)


@app.errorhandler(404)
def not_found(error):
    return render_template("404.html"), 404


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
