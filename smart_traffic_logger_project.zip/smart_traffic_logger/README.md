# Smart Traffic Violation Logger

A Flask mini project for recording traffic violations, storing them in SQLite, managing Paid/Unpaid status, searching history, and generating a QR code for every challan.

## Technologies
- Python
- Flask
- Flask-SQLAlchemy
- SQLite
- HTML/CSS
- Python qrcode

## Run in VS Code

1. Open this folder in VS Code.
2. Create a virtual environment:
   `python -m venv venv`
3. Activate it on Windows:
   `venv\Scripts\activate`
4. Install packages:
   `pip install -r requirements.txt`
5. Start:
   `python app.py`
6. Open:
   `http://127.0.0.1:5000`

## QR phone demo

For scanning from a phone:
1. Connect the laptop and phone to the same Wi-Fi/hotspot.
2. Run `ipconfig` in Windows CMD and find the laptop IPv4 address.
3. Keep the app running with `host="0.0.0.0"`.
4. Open `http://YOUR-LAPTOP-IP:5000` on the phone once to verify access.
5. Add a violation.
6. Open its detail page and scan the displayed QR code using the phone camera/Google Lens.
7. The QR opens `/status/<id>` and shows the violation details and Paid/Unpaid status.

Note: The QR uses the current host URL, so create the violation while accessing the app through the same LAN address when you want the QR to work directly on another device.
