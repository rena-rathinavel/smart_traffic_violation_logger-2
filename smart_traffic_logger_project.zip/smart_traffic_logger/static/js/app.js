document.addEventListener("DOMContentLoaded", () => {
    const vehicle = document.querySelector("#vehicle_number");
    if (vehicle) {
        vehicle.addEventListener("input", () => {
            vehicle.value = vehicle.value.toUpperCase();
        });
    }

    document.querySelectorAll(".flash").forEach((el) => {
        setTimeout(() => {
            el.style.opacity = "0";
            el.style.transform = "translateY(-4px)";
            el.style.transition = "all .35s ease";
            setTimeout(() => el.remove(), 350);
        }, 4500);
    });
});
